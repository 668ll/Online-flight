package com.example.airplaindemo.ui.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;

import com.example.airplaindemo.BaseActivity;
import com.example.airplaindemo.MyDatabaseHelper;
import com.example.airplaindemo.R;
import com.example.airplaindemo.adapter.PassengerAdapter;
import com.example.airplaindemo.list.PassengerData;

import java.util.ArrayList;
import java.util.List;

public class PassengerActivity extends BaseActivity {

    private ListView mLvPassenger;
    private MyDatabaseHelper dbHelper;
    private PassengerAdapter adapter;
    private PassengerData mPassengerData;
    private List<PassengerData> mListItems;
    private SQLiteDatabase db;
    private Cursor cursor;
    private String mStrName, mStrTel, mStrNumber, user_name;

    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger);

        user_name = getIntent().getStringExtra("user_name");
        mLvPassenger = (ListView) this.findViewById(R.id.lv_dialog_passenger);
        ImageView mIvClose = (ImageView) this.findViewById(R.id.iv_close);
        ImageView mIvAdd = (ImageView) this.findViewById(R.id.iv_add);

        mIvClose.setOnClickListener(view -> finish());

        init();
        mIvAdd.setOnClickListener(v -> {
            Intent intent = new Intent(this, PassengerEditActivity.class);
            intent.putExtra("user_name",user_name);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        init();
    }

    @SuppressLint("Range")
    public void init() {
        dbHelper = new MyDatabaseHelper(this, "passengerStore.db", null, 1);
        db = dbHelper.getReadableDatabase();
        mListItems = new ArrayList<>();
        adapter = new PassengerAdapter(mListItems, this);
        cursor = db.query("passenger", new String[]{"passenger_name", "passenger_tel", "passenger_num"}, "user_name=?", new String[]{user_name}, null, null, null);

        if (mListItems != null) {
            mListItems.clear();
            mLvPassenger.setAdapter(adapter);
        }
        if (cursor.moveToFirst()) {
            do {
                mPassengerData = new PassengerData();
                mStrName = cursor.getString(cursor.getColumnIndex("passenger_name"));
                mStrTel = cursor.getString(cursor.getColumnIndex("passenger_tel"));
                mStrNumber = cursor.getString(cursor.getColumnIndex("passenger_num"));
                mPassengerData.name = mStrName;
                mPassengerData.tel = mStrTel;
                mPassengerData.number = mStrNumber;
                mListItems.add(mPassengerData);
            } while (cursor.moveToNext());
        }
        try {
            cursor.close();
        } finally {
            cursor.close();
        }
        mLvPassenger.setAdapter(adapter);

        mLvPassenger.setOnItemClickListener((adapterView, view, i, l) -> {
            mPassengerData = mListItems.get(i);
            String name = mPassengerData.name;
            String tel = mPassengerData.tel;
            String number = mPassengerData.number;
            Intent intent = new Intent();
            intent.putExtra("passenger_name", name);
            intent.putExtra("passenger_tel", tel);
            intent.putExtra("passenger_num", number);
            setResult(RESULT_OK, intent);
            finish();
        });
    }
}