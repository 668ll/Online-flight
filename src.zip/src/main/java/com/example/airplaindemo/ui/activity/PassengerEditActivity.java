package com.example.airplaindemo.ui.activity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.example.airplaindemo.BaseActivity;
import com.example.airplaindemo.MyDatabaseHelper;
import com.example.airplaindemo.R;
import com.example.airplaindemo.util.KeyBoardUtils;

public class PassengerEditActivity extends BaseActivity {

    private EditText mEtName, mEtTel, mEtNum;
    private Button mBtAdd1, mBtCancel;
    private String mStrUser, mStrName, mStrTel, mStrNum;
    private MyDatabaseHelper dbHelper;
    private SQLiteDatabase db;
    private Cursor cursor;
    private ContentValues values;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger_eidt);
        mStrUser = getIntent().getStringExtra("user_name");

        mEtName = (EditText) this.findViewById(R.id.et_add_passenger_name);
        mEtTel = (EditText) this.findViewById(R.id.et_add_passenger_tel);
        mEtNum = (EditText) this.findViewById(R.id.et_add_passenger_num);
        mBtAdd1 = (Button) this.findViewById(R.id.bt_passenger_add1);
        ImageView mIvBack = findViewById(R.id.iv_back);
        mIvBack.setOnClickListener(v -> finish());

        dbHelper = new MyDatabaseHelper(this, "passengerStore.db", null, 1);
        db = dbHelper.getWritableDatabase();
        mBtAdd1.setOnClickListener(v -> {
            mStrName = mEtName.getText().toString();
            mStrTel = mEtTel.getText().toString();
            mStrNum = mEtNum.getText().toString();
            values = new ContentValues();
            if (!TextUtils.isEmpty(mStrName) && !TextUtils.isEmpty(mStrTel) && !TextUtils.isEmpty(mStrNum)) {
                values.put("user_name", mStrUser);
                values.put("passenger_name", mStrName);
                values.put("passenger_tel", mStrTel);
                values.put("passenger_num", mStrNum);
                db.insert("passenger", null, values);
                values.clear();

                finish();
            }
        });


    }

    /**
     * 点击空白处
     * 输入框消失
     */
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {//获取当前获得焦点的View
            View view = getCurrentFocus();
            //调用方法判断是否需要隐藏键盘
            KeyBoardUtils.hideKeyboard(ev, view, this);
        }
        return super.dispatchTouchEvent(ev);
    }
}