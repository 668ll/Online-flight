package com.example.airplaindemo.ui.fragment;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.airplaindemo.MyDatabaseHelper;
import com.example.airplaindemo.R;
import com.example.airplaindemo.adapter.FlightListAdapter;
import com.example.airplaindemo.list.FlightsData;
import com.example.airplaindemo.ui.activity.BuyActivity;
import com.example.airplaindemo.util.ToastDialogUtil;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * @author Run
 * @date 2023/3/14
 * @description User mode flight information
 */
public class UserFlightFragment extends Fragment {

    private MyDatabaseHelper dbHelper;
    private ListView mLvFlights;
    private FlightListAdapter adapter;
    private List<FlightsData> mListItems;
    private FlightsData mFlightsData;
    private String user_name;
    private String mSqlId, mSqlNo, mSqlStd, mSqlEnd, mSqlFrom, mSqlTo, mSqlMoney, mSqlNum;
    private RelativeLayout mRlFlight, mRlEmpty;
    private TextView mTvDate;
    private ImageView mIvClear;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_user_flight, container, false);
    }

    @SuppressLint("Range")
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        init();
    }

    @Override
    public void onResume() {
        super.onResume();
        init();
    }

    @SuppressLint("Range")
    public void init() {
        mRlFlight = getActivity().findViewById(R.id.rl_flights);
        mRlEmpty = getActivity().findViewById(R.id.rl_flights_empty);
        mRlEmpty.bringToFront();
        mTvDate = getActivity().findViewById(R.id.tv_date);
        dbHelper = new MyDatabaseHelper(getActivity(), "flightsStore.db", null, 1);
        dbHelper.getWritableDatabase();

        Bundle bundle = getArguments();
        assert bundle != null;
        user_name = (String) bundle.getString("mine_user");

        mListItems = new ArrayList<>();
        adapter = new FlightListAdapter(mListItems, getActivity());

        mLvFlights = (ListView) getActivity().findViewById(R.id.lv_user_flights);
        function("");
        mIvClear = (ImageView) getActivity().findViewById(R.id.iv_clear);
        mIvClear.setOnClickListener(v -> {
            mTvDate.setText("Select flight departure time");
            function("");
        });
        mTvDate.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            // Create and show a DatePickerDialog
            new DatePickerDialog(getActivity(),
                    // Bind listener
                    (view, year, monthOfYear, dayOfMonth) -> {
                        int int_month = Integer.parseInt(String.valueOf(monthOfYear + 1));
                        String mStrMonth = String.valueOf(int_month);
                        String mStrDay = String.valueOf(dayOfMonth);
                        if (mStrMonth.length() == 1) {
                            mStrMonth = "0" + mStrMonth;
                        }
                        if (mStrDay.length() == 1) {
                            mStrDay = "0" + mStrDay;
                        }
                        String date = year + " year " + mStrMonth
                                + " month " + mStrDay + " day";
                        mTvDate.setText(date);
                        function(date);
                    }
                    // Set initial date
                    , c.get(Calendar.YEAR), c.get(Calendar.MONTH), c
                    .get(Calendar.DAY_OF_MONTH)).show();

        });

        mLvFlights.setOnItemClickListener((parent, view, position, id) -> {
            mFlightsData = mListItems.get(position);
            Log.i("Output", mFlightsData.getFlightNo());
            if (mFlightsData.getFlightNum().equals("0")) {
                ToastDialogUtil.showToast(getActivity(), "No available tickets");
            } else {
                Intent intent = new Intent(getActivity(), BuyActivity.class);
                intent.putExtra("id", mFlightsData.getId());
                intent.putExtra("flights_no", mFlightsData.getFlightNo());
                intent.putExtra("flights_std", mFlightsData.getFlightStd());
                intent.putExtra("flights_end", mFlightsData.getFlightEnd());
                intent.putExtra("flights_from", mFlightsData.getFlightFrom());
                intent.putExtra("flights_to", mFlightsData.getFlightTo());
                intent.putExtra("flights_money", mFlightsData.getFlightMoney());
                intent.putExtra("flights_num", mFlightsData.getFlightNum());
                intent.putExtra("user_name", user_name);
                startActivity(intent);
            }

        });
    }

    // Search function
    @SuppressLint("Range")
    public void function(String no) {
        if (mListItems != null) {
            mListItems.clear();
            mLvFlights.setAdapter(adapter);
        }
        String mKeyName = "SELECT*FROM flights where flights_std like '%" + no + "%'";
        SQLiteDatabase db1 = dbHelper.getReadableDatabase();
        Cursor cursor1 = db1.rawQuery(mKeyName, null);
        if (cursor1.moveToFirst()) {
            do {
                mFlightsData = new FlightsData();
                mSqlId = cursor1.getString(cursor1.getColumnIndex("id"));
                mSqlNo = cursor1.getString(cursor1.getColumnIndex("flights_no"));
                mSqlStd = cursor1.getString(cursor1.getColumnIndex("flights_std"));
                mSqlEnd = cursor1.getString(cursor1.getColumnIndex("flights_end"));
                mSqlFrom = cursor1.getString(cursor1.getColumnIndex("flights_from"));
                mSqlTo = cursor1.getString(cursor1.getColumnIndex("flights_to"));
                mSqlMoney = cursor1.getString(cursor1.getColumnIndex("flights_money"));
                mSqlNum = cursor1.getString(cursor1.getColumnIndex("flights_num"));
                mFlightsData.id = mSqlId;
                mFlightsData.flights_no = mSqlNo;
                mFlightsData.flights_std = mSqlStd;
                mFlightsData.flights_end = mSqlEnd;
                mFlightsData.flights_from = mSqlFrom;
                mFlightsData.flights_to = mSqlTo;
                mFlightsData.flights_money = mSqlMoney;
                mFlightsData.flights_num = mSqlNum;
                mListItems.add(mFlightsData);
            } while (cursor1.moveToNext());
        }
        try {
            cursor1.close();
        } finally {
            cursor1.close();
        }
        cursor1.close();
        if (cursor1.getCount() == 0 || mListItems.isEmpty() || adapter.isEmpty()) {
            mRlEmpty.setVisibility(View.VISIBLE);
        } else {
            mRlEmpty.setVisibility(View.GONE);
            mLvFlights.setAdapter(adapter);
        }
    }

}
