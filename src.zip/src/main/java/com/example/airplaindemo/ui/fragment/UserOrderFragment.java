package com.example.airplaindemo.ui.fragment;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.airplaindemo.MyDatabaseHelper;
import com.example.airplaindemo.R;
import com.example.airplaindemo.adapter.OrderListAdapter;
import com.example.airplaindemo.list.OrdersData;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Run
 * @date 2023/3/14
 * @description 用户模式订单信息
 */
public class UserOrderFragment extends Fragment {

    private MyDatabaseHelper dbHelper;
    private ListView mLvOrder;
    private OrderListAdapter adapter;
    private List<OrdersData> mListItems;
    private OrdersData mOrdersData;
    private String user_name;
    private String order_user, passenger_name, passenger_tel, passenger_num, flights_no, flights_std, order_money, order_way;

    private RelativeLayout mRlEmpty;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_user_order, container, false);
    }

    @SuppressLint("Range")
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        init();
    }

    @Override
    public void onResume() {
        super.onResume();
        init();
    }

    @SuppressLint("Range")
    public void init() {
        dbHelper = new MyDatabaseHelper(getActivity(), "ordersStore.db", null, 1);
        dbHelper.getWritableDatabase();

        Bundle bundle = getArguments();
        assert bundle != null;
        user_name = (String) bundle.getString("mine_user");

        mListItems = new ArrayList<>();
        adapter = new OrderListAdapter(mListItems, getActivity());

        mLvOrder = (ListView) getActivity().findViewById(R.id.lv_order);
        mRlEmpty = getActivity().findViewById(R.id.rl_order_empty);
        String selectQuery = "SELECT*FROM orders where order_user like '%" + user_name + "%' ";
        SQLiteDatabase db1 = dbHelper.getReadableDatabase();
        Cursor cursor = db1.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                mOrdersData = new OrdersData();

                order_user = cursor.getString(cursor.getColumnIndex("order_user"));
                passenger_num = cursor.getString(cursor.getColumnIndex("passenger_num"));
                passenger_name = cursor.getString(cursor.getColumnIndex("passenger_name"));
                flights_no = cursor.getString(cursor.getColumnIndex("flights_no"));
                flights_std = cursor.getString(cursor.getColumnIndex("flights_std"));
                order_money = cursor.getString(cursor.getColumnIndex("order_money"));
                passenger_tel = cursor.getString(cursor.getColumnIndex("passenger_tel"));
                order_way = cursor.getString(cursor.getColumnIndex("order_way"));
                mOrdersData.passenger_num = passenger_num;
                mOrdersData.order_user = order_user;
                mOrdersData.passenger_name = passenger_name;
                mOrdersData.passenger_tel = passenger_tel;
                mOrdersData.flights_no = flights_no;
                mOrdersData.flights_std = flights_std;
                mOrdersData.order_money = order_money;
                mOrdersData.order_way = order_way;
                mListItems.add(mOrdersData);
            } while (cursor.moveToNext());
        }
        cursor.close();
        if (cursor.getCount() == 0) {
            mRlEmpty.setVisibility(View.VISIBLE);
            Log.i("UserAdoptActivity", "c.getCount=0");
        } else {
            mRlEmpty.setVisibility(View.GONE);
            mLvOrder.setAdapter(adapter);
        }
        mLvOrder.setAdapter(adapter);
    }
}
