package com.example.airplaindemo.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.airplaindemo.R;
import com.example.airplaindemo.list.OrdersData;

import java.util.List;

/**
 * 作者 : Run
 * 日期 : 2023/3/15
 * 描述 : 订单adapter
 */

public class OrderListAdapter extends BaseAdapter {

    private final List<OrdersData> mOrdersData;
    private final LayoutInflater inflater;

    public OrderListAdapter(List<OrdersData> mOrdersData, Context context) {
        this.mOrdersData = mOrdersData;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return mOrdersData == null ? 0 : mOrdersData.size();
    }

    @Override
    public Object getItem(int position) {
        return mOrdersData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressLint({"SetTextI18n", "MissingInflatedId"})
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = inflater.inflate(R.layout.item_order, null);
        OrdersData mOrdersData = (OrdersData) getItem(position);

        TextView order_no = (TextView) view.findViewById(R.id.tv_order_no);
        TextView order_way = (TextView) view.findViewById(R.id.tv_order_way);
        TextView order_name = (TextView) view.findViewById(R.id.tv_order_name);
        TextView order_tel = (TextView) view.findViewById(R.id.tv_order_tel);
        TextView order_num = (TextView) view.findViewById(R.id.tv_order_num);
        TextView order_std = (TextView) view.findViewById(R.id.tv_order_std);
        TextView order_user = (TextView) view.findViewById(R.id.tv_order_user);
        TextView order_money = (TextView) view.findViewById(R.id.tv_order_money);

        order_no.setText(mOrdersData.getFlightsNo());
        order_name.setText(mOrdersData.getPassengerName());
        order_money.setText("下单金额：" + mOrdersData.getOrderMoney());
        order_way.setText("支付方式：" + mOrdersData.getOrderWay());
        order_tel.setText("联系方式：" + mOrdersData.getPassengerTel());
        order_std.setText("起飞时间:" + mOrdersData.getFlightsStd());
        order_user.setText("下单用户:" + mOrdersData.getOrderUser());
        order_num.setText("身份证号:" + mOrdersData.getPassengerNum());

        return view;
    }
}
