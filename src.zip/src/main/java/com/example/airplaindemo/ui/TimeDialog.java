package com.example.airplaindemo.ui;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.airplaindemo.R;
import com.example.airplaindemo.ui.activity.FlightEditActivity;

/**
 * @author Run
 * @date 2024/5/21
 * @description
 */
public class TimeDialog extends Dialog {

    public TimeDialog(Context context, int type) {
        super(context);
        setContentView(R.layout.dialog_layout);
        EditText year = findViewById(R.id.dialog_year);
        EditText month = findViewById(R.id.dialog_month);
        EditText day = findViewById(R.id.dialog_day);
        EditText hour = findViewById(R.id.dialog_hour);
        EditText minute = findViewById(R.id.dialog_minute);
        Button btnConfirm = findViewById(R.id.bt_dialog_yes);

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mStrYear = year.getText().toString();
                String mStrMonth = month.getText().toString();
                String mStrDay = day.getText().toString();
                String mStrHour = hour.getText().toString();
                String mStrMinute = minute.getText().toString();
                if (year.length() != 4 || month.length() != 2 || day.length() != 2 || hour.length() != 2 || minute.length() != 2) {
                    Toast.makeText(context, "请输入正确格式", Toast.LENGTH_SHORT).show();
                } else if (Integer.parseInt(mStrMonth) > 12 || Integer.parseInt(mStrDay) > 31 || Integer.parseInt(mStrHour) > 24 || Integer.parseInt(mStrMinute) > 60) {
                    Toast.makeText(context, "请输入正确格式", Toast.LENGTH_SHORT).show();
                } else {
                    final String time = mStrYear + "年" + mStrMonth + "月" + mStrDay + "日" + mStrHour + "时" + mStrMinute + "分";
                    ((FlightEditActivity) context).updateTextView(type, time);
                    dismiss();
                }


            }
        });
    }

}
