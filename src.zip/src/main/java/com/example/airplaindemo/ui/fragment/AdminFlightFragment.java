package com.example.airplaindemo.ui.fragment;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.airplaindemo.MyDatabaseHelper;
import com.example.airplaindemo.R;
import com.example.airplaindemo.adapter.FlightListAdapter;
import com.example.airplaindemo.list.FlightsData;
import com.example.airplaindemo.ui.activity.FlightEditActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Run
 * @date 2023/3/14
 * @description Admin mode for flight information
 */
public class AdminFlightFragment extends Fragment {

    private List<FlightsData> mListItems;
    private FlightListAdapter adapter;
    private FlightsData mFlightsData;
    private MyDatabaseHelper dbHelper;
    private SQLiteDatabase db;
    private ContentValues values;
    private RelativeLayout mRlFlight, mRlEmpty;
    private ListView mLvFlight;
    private ImageView mIvAdd;
    private EditText mEtSearch;
    private String mSqlId, mSqlNo, mSqlStd, mSqlEnd, mSqlFrom, mSqlTo, mSqlMoney, mSqlNum;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_admin_flight, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        init();
        setEtSearch(mEtSearch);
    }

    @Override
    public void onResume() {
        super.onResume();
        init();
    }

    @SuppressLint("Range")
    public void init() {
        mRlFlight = getActivity().findViewById(R.id.rl_flights);
        mRlEmpty = getActivity().findViewById(R.id.rl_flights_empty);
        mRlEmpty.bringToFront();
        mEtSearch = getActivity().findViewById(R.id.ed_search);
        mIvAdd = getActivity().findViewById(R.id.iv_add);

        dbHelper = new MyDatabaseHelper(getActivity(), "flightsStore.db", null, 1);
        db = dbHelper.getWritableDatabase();
        values = new ContentValues();

        mListItems = new ArrayList<>();
        adapter = new FlightListAdapter(mListItems, getActivity());

        mLvFlight = getActivity().findViewById(R.id.lv_flights);

        mLvFlight.setAdapter(adapter);
        mListItems.clear();
        adapter.notifyDataSetChanged();

        function("");

        mLvFlight.setOnItemClickListener((parent, view, position, id) -> {
            mFlightsData = mListItems.get(position);
            Log.i("Flight Info", mFlightsData.getFlightNo()); // TODO: Change to id
            Intent intent = new Intent(getActivity(), FlightEditActivity.class);
            intent.putExtra("flights_id", mFlightsData.getId());
            intent.putExtra("flights_edit", "update");
            startActivity(intent);
        });

        mLvFlight.setOnItemLongClickListener((adapterView, view, i, l) -> {
            mFlightsData = mListItems.get(i);
            AlertDialog dialog = new AlertDialog.Builder(getActivity())
                    .setMessage("Are you sure you want to delete this flight?")
                    .setPositiveButton("Delete", (dialogInterface, i1) -> {
                        if (!TextUtils.isEmpty(mFlightsData.id)) {
                            db = dbHelper.getWritableDatabase();
                            db.delete("flights", "id=?", new String[]{mFlightsData.id});
                            init();
                        } else {
                            Log.e("AdminFlightFragment", mFlightsData.id + " has been deleted");
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .create();
            dialog.show();
            return true;
        });

        mIvAdd.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), FlightEditActivity.class);
            intent.putExtra("flights_edit", "add");
            startActivity(intent);
        });
    }

    //<editor-fold defaultstate="collapsed" desc="Search box query">
    // Listen to the EditText
    public void setEtSearch(EditText mEt) {
        mEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
                if (mListItems != null) {
                    mListItems.clear();
                    mLvFlight.setAdapter(adapter);
                }
                function("");
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                if (mListItems != null) {
                    mListItems.clear();
                    mLvFlight.setAdapter(adapter);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (mListItems != null) {
                    mListItems.clear();
                    mLvFlight.setAdapter(adapter);
                }
                String key = mEtSearch.getText().toString();
                function(key);
            }
        });
    }

    // Search function
    @SuppressLint("Range")
    public void function(String no) {
        String mKeyName = "SELECT * FROM flights WHERE flights_no LIKE '%" + no + "%'";
        SQLiteDatabase db1 = dbHelper.getReadableDatabase();
        Cursor cursor1 = db1.rawQuery(mKeyName, null);
        if (cursor1.moveToFirst()) {
            do {
                mFlightsData = new FlightsData();
                mSqlId = cursor1.getString(cursor1.getColumnIndex("id"));
                mSqlNo = cursor1.getString(cursor1.getColumnIndex("flights_no"));
                mSqlStd = cursor1.getString(cursor1.getColumnIndex("flights_std"));
                mSqlEnd = cursor1.getString(cursor1.getColumnIndex("flights_end"));
                mSqlFrom = cursor1.getString(cursor1.getColumnIndex("flights_from"));
                mSqlTo = cursor1.getString(cursor1.getColumnIndex("flights_to"));
                mSqlMoney = cursor1.getString(cursor1.getColumnIndex("flights_money"));
                mSqlNum = cursor1.getString(cursor1.getColumnIndex("flights_num"));

                mFlightsData.id = mSqlId;
                mFlightsData.flights_no = mSqlNo;
                mFlightsData.flights_std = mSqlStd;
                mFlightsData.flights_end = mSqlEnd;
                mFlightsData.flights_from = mSqlFrom;
                mFlightsData.flights_to = mSqlTo;
                mFlightsData.flights_money = mSqlMoney;
                mFlightsData.flights_num = mSqlNum;
                mListItems.add(mFlightsData);
            } while (cursor1.moveToNext());
        }
        try {
            cursor1.close();
        } finally {
            cursor1.close();
        }
        cursor1.close();
        if (cursor1.getCount() == 0 || mListItems.isEmpty() || adapter.isEmpty()) {
            mRlEmpty.setVisibility(View.VISIBLE);
        } else {
            mRlEmpty.setVisibility(View.GONE);
            mLvFlight.setAdapter(adapter);
        }
    }
    //</editor-fold>
}
