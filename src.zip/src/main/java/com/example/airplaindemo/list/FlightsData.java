package com.example.airplaindemo.list;

/**
 * 作者 : Run
 * 日期 : 2023/3/15
 * 描述 : 航班记录数据
 */

public class FlightsData {
    public String id;
    public String flights_no;
    public String flights_std;
    public String flights_end;
    public String flights_from;
    public String flights_to;
    public String flights_money;
    public String flights_num;


    public String getId() {
        return id == null ? "" : id;
    }

    public void setId(String id) {
        this.id = id;
    }
    public String getFlightNo() {
        return flights_no == null ? "" : flights_no;
    }

    public void setFlightNo(String flights_no) {
        this.flights_no = flights_no;
    }

    public String getFlightStd() {
        return flights_std == null ? "" : flights_std;
    }

    public void setFlightStd(String flights_std) {
        this.flights_std = flights_std;
    }

    public String getFlightFrom() {
        return flights_from == null ? "" : flights_from;
    }

    public void setFlightFrom(String flights_from) {
        this.flights_from = flights_from;
    }

    public String getFlightTo() {
        return flights_to == null ? "" : flights_to;
    }

    public void setFlightTo(String flights_to) {
        this.flights_to = flights_to;
    }

    public String getFlightEnd() {
        return flights_end == null ? "" : flights_end;
    }

    public void setFlightEnd(String flights_end) {
        this.flights_end = flights_end;
    }

    public String getFlightMoney() {
        return flights_money == null ? "" : flights_money;
    }

    public void setFlightMoney(String flights_money) {
        this.flights_money = flights_money;
    }
    public String getFlightNum() {
        return flights_num == null ? "" : flights_num;
    }

    public void setFlightNum(String flights_num) {
        this.flights_num = flights_num;
    }

}
