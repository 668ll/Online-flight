package com.example.airplaindemo.list;

/**
 * 作者 : Run
 * 日期 : 2023/3/15
 * 描述 : 订单记录数据
 */

public class OrdersData {
    public String id;
    public String order_user;
    public String order_way;
    public String order_money;
    public String passenger_name;
    public String passenger_tel;
    public String passenger_num;
    public String flights_no;
    public String flights_std;
    public String getId() {
        return id == null ? "" : id;
    }

    public void setId(String id) {
        this.id = id;
    }
    public String getOrderUser() {
        return order_user == null ? "" : order_user;
    }

    public void setOrderUser(String order_user) {
        this.order_user = order_user;
    }
    public String getOrderWay() {
        return order_way == null ? "" : order_way;
    }

    public void setOrderWay(String order_way) {
        this.order_way = order_way;
    }
    public String getOrderMoney() {
        return order_money == null ? "" : order_money;
    }

    public void setOrderMoney(String order_money) {
        this.order_money = order_money;
    }



    public String getPassengerName() {
        return passenger_name == null ? "" : passenger_name;
    }
    public void setPassengerName(String passenger_name) {
        this.passenger_name = passenger_name;
    }

    public String getPassengerTel() {
        return passenger_tel == null ? "" : passenger_tel;
    }

    public void setPassengerTel(String passenger_tel) {
        this.passenger_tel = passenger_tel;
    }
    public String getPassengerNum() {
        return passenger_num == null ? "" : passenger_num;
    }
    public void setPassengerNum(String passenger_num) {
        this.passenger_num = passenger_num;
    }
    public String getFlightsNo() {
        return flights_no == null ? "" : flights_no;
    }
    public void setFlightsNo(String flights_no) {
        this.flights_no = flights_no;
    }
    public String getFlightsStd() {
        return flights_std == null ? "" : flights_std;
    }
    public void setFlightsStd(String flights_gate) {
        this.flights_std = flights_std;
    }

}
