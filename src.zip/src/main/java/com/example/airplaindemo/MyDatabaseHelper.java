package com.example.airplaindemo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Run on 2021/3/26.
 */
public class MyDatabaseHelper extends SQLiteOpenHelper {

    public static final String CREATE_USERS = "create table users ("//用户数据库
            + "id integer primary key autoincrement,"
            + "user_name text,"         //用户名（用户名）
            + "user_code text,"         //密码
            + "user_status text)";


    public static final String CREATE_FLIGHTS = "create table flights("//航班数据库
            + "id integer primary key autoincrement,"
            + "flights_no text,"          //航班号
            + "flights_std text,"         //起飞时间
            + "flights_end text,"         //落地时间
            + "flights_from text,"        //航班起点
            + "flights_to text,"          //航班终点
            + "flights_money text,"       //航班钱
            + "flights_num text)";        //余票

    public static final String CREATE_ORDERS = "create table orders("//订单数据库
            + "id integer primary key autoincrement,"
            + "order_user text,"         //下单用户
            + "order_way text,"          //支付方式
            + "order_money text,"        //支付金额
            + "passenger_name text,"     //乘机人姓名
            + "passenger_tel text,"      //联系方式
            + "passenger_num text,"      //身份证号
            + "flights_no text,"         //航班号
            + "flights_std text)";       //起飞时间

    public static final String CREATE_PASSENGER = "create table passenger("//乘机人数据库
            + "id integer primary key autoincrement,"
            + "user_name text,"          //乘机人姓名
            + "passenger_name text,"          //乘机人姓名
            + "passenger_tel text,"           //联系方式
            + "passenger_num text)";          //身份证号

//    public static final String CREATE_CARD = "create table card("//银行卡数据库
//            + "id integer primary key autoincrement,"
//            + "card_name text,"          //卡银行
//            + "card_num text)";          //卡号
    private Context mContext;

    public MyDatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS);
        db.execSQL(CREATE_FLIGHTS);
        db.execSQL(CREATE_ORDERS);
        db.execSQL(CREATE_PASSENGER);
//        db.execSQL(CREATE_CARD);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists users");
        db.execSQL("drop table if exists flights");
        db.execSQL("drop table if exists orders");
        db.execSQL("drop table if exists passenger");
//        db.execSQL("drop table if exists card");

        onCreate(db);
    }
}