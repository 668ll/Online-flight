package com.example.airplaindemo.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.airplaindemo.R;
import com.example.airplaindemo.list.FlightsData;

import java.util.List;

/**
 * Author : Run
 * Date : 2023/3/15
 * Description : Flight adapter
 */

public class FlightListAdapter extends BaseAdapter {

    private final List<FlightsData> mFlightsData;
    private final LayoutInflater inflater;

    public FlightListAdapter(List<FlightsData> mFlightsData, Context context) {
        this.mFlightsData = mFlightsData;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return mFlightsData == null ? 0 : mFlightsData.size();
    }

    @Override
    public Object getItem(int position) {
        return mFlightsData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressLint({"SetTextI18n", "MissingInflatedId"})
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = inflater.inflate(R.layout.item_flight, null);
        FlightsData mFlightsData = (FlightsData) getItem(position);

        TextView no = (TextView) view.findViewById(R.id.tv_flights_no);
        TextView std = (TextView) view.findViewById(R.id.tv_flights_std);
        TextView end = (TextView) view.findViewById(R.id.tv_flights_end);
        TextView total = (TextView) view.findViewById(R.id.tv_flights_total);
        TextView from = (TextView) view.findViewById(R.id.tv_flights_from);
        TextView to = (TextView) view.findViewById(R.id.tv_flights_to);
        TextView money = (TextView) view.findViewById(R.id.tv_flights_money);
        TextView num = (TextView) view.findViewById(R.id.tv_flights_num);

        String[] std_list = mFlightsData.getFlightStd().split("[YearMonthDayHourMinute]+");
        String[] end_list = mFlightsData.getFlightEnd().split("[YearMonthDayHourMinute]+");

        int year = Integer.parseInt(std_list[0]) - Integer.parseInt(end_list[0]);
        int month = Integer.parseInt(std_list[1]) - Integer.parseInt(end_list[1]);
        int day = Integer.parseInt(std_list[2]) - Integer.parseInt(end_list[2]);
        int hour = Integer.parseInt(std_list[3]) - Integer.parseInt(end_list[3]);
        int minute = Integer.parseInt(std_list[4]) - Integer.parseInt(end_list[4]);
        int int_total = hour * 60 + day * 24 * 60 + month * 12 * 24 * 60 + minute;
        no.setText("Flight No.:" + mFlightsData.getFlightNo());
        std.setText("Dep time:" + mFlightsData.getFlightStd());
        end.setText("Landing time:" + mFlightsData.getFlightEnd());
        from.setText("Origin:" + mFlightsData.getFlightFrom());
        to.setText("Destination:" + mFlightsData.getFlightTo());
        String[] list_total = String.valueOf(int_total).split("-");
        total.setText("Duration: " + list_total[1] + " Min");
        money.setText("Price: " + mFlightsData.getFlightMoney() + "¥");
        num.setText("Remaining: " + mFlightsData.getFlightNum());
        return view;
    }

}
