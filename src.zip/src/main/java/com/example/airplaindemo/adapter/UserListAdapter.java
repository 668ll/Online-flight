package com.example.airplaindemo.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.airplaindemo.R;
import com.example.airplaindemo.list.UserData;

import java.util.List;

/**
 * 作者 : Run
 * 日期 : 2023/3/14
 * 描述 : 用户adapter
 */

public class UserListAdapter extends BaseAdapter {

    private final List<UserData> mUserDataList;
    private final LayoutInflater inflater;

    public UserListAdapter(List<UserData> mUserDataList, Context context) {
        this.mUserDataList = mUserDataList;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return mUserDataList == null ? 0 : mUserDataList.size();
    }

    @Override
    public Object getItem(int position) {
        return mUserDataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = inflater.inflate(R.layout.item_user, null);
        UserData mUserData = (UserData) getItem(position);

        TextView tv_name = (TextView) view.findViewById(R.id.tv_name_title);
        TextView tv_password = (TextView) view.findViewById(R.id.tv_password_title);
        TextView tv_status = (TextView) view.findViewById(R.id.tv_status_title);

        String mStrStatus = mUserData.getStatus();
        tv_status.setText(mStrStatus);
        if (mStrStatus.equals("正常")) {
            tv_status.setBackgroundColor(Color.GREEN);
        } else if (mStrStatus.equals("黑名单")) {
            tv_status.setBackgroundColor(Color.RED);
        } else {
            Log.e("UserListAdapter", mUserData.name + "状态报错");
        }
        tv_name.setText("用户名 : " + mUserData.getName());
        tv_password.setText("密   码 :  " + mUserData.getPassword());
        return view;
    }
}
