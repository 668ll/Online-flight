package com.example.airplaindemo.ui.activity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.airplaindemo.BaseActivity;
import com.example.airplaindemo.MyDatabaseHelper;
import com.example.airplaindemo.R;
import com.example.airplaindemo.util.KeyBoardUtils;


/**
 * @author Run
 * @date 2022/3/3
 * @description 注册页
 */
public class RegisterActivity extends BaseActivity implements View.OnClickListener {

    private EditText mPhone, mPassword, mSurePassword;
    private MyDatabaseHelper dbHelper;
    private Button mRegister, mCancel;
    private RelativeLayout register, wait;
    private String name1, mKeyUSer, mSqlUser, code1, code2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        if (savedInstanceState != null) {
            name1 = savedInstanceState.getString("name1");
            code1 = savedInstanceState.getString("code1");
            code2 = savedInstanceState.getString("code2");
            mPhone.setText(name1);
            mPassword.setText(code1);
            mSurePassword.setText(code2);
        }

        mPhone = findViewById(R.id.et_phone_register);
        mPassword = findViewById(R.id.et_password_register);
        mSurePassword = findViewById(R.id.et_password_sure_register);

        mRegister = findViewById(R.id.bt_register);
        mCancel = findViewById(R.id.bt_cancel_register);
        mRegister.setOnClickListener(this);
        mCancel.setOnClickListener(this);

        register = findViewById(R.id.rl_register);
        wait = findViewById(R.id.rl_wait);
        register.setVisibility(View.VISIBLE);
        wait.setVisibility(View.GONE);

        dbHelper = new MyDatabaseHelper(RegisterActivity.this, "usersStore.db", null, 1);
        dbHelper.getWritableDatabase();
    }

    @Override
    public void onClick(View view) {
        if (view.getId()==R.id.bt_cancel_register){
            finish();
        } else if (view.getId()==R.id.bt_register) {
            register.setVisibility(View.GONE);
            wait.setVisibility(View.VISIBLE);
            register();
        }
    }

    @SuppressLint("Range")
    public void register() {
        name1 = mPhone.getText().toString();
        code1 = mPassword.getText().toString();
        code2 = mSurePassword.getText().toString();

        if (name1.equals("") || code1.equals("") || code2.equals("") || !code1.equals(code2)) {
            Toast.makeText(RegisterActivity.this, "注册失败，请更正后重新注册", Toast.LENGTH_SHORT).show();
            register.setVisibility(View.VISIBLE);
            wait.setVisibility(View.GONE);
            mPhone.setText("");
            mPassword.setText("");
            mSurePassword.setText("");
            return;
        }

        mKeyUSer = "SELECT*FROM users where user_name like '%" + name1 + "%'";
        SQLiteDatabase db1 = dbHelper.getReadableDatabase();
        Cursor cursor1 = db1.rawQuery(mKeyUSer, null);
        if (cursor1.moveToFirst()) {
            do {
                mSqlUser = cursor1.getString(cursor1.getColumnIndex("user_name"));
            } while (cursor1.moveToNext());
        }
        try {
            cursor1.close();
        } finally {
            cursor1.close();
        }
        cursor1.close();

        if (name1.equals(mSqlUser) || name1.equals("admin")) {
            Toast.makeText(this, "该用户名已被注册", Toast.LENGTH_LONG).show();
            register.setVisibility(View.VISIBLE);
            wait.setVisibility(View.GONE);
            return;
        }

        if (code1.length() <= 5 || code1.length() > 9) {
            Toast.makeText(this, "密码长度在6-9位", Toast.LENGTH_LONG).show();
            register.setVisibility(View.VISIBLE);
            wait.setVisibility(View.GONE);
            return;
        }
        myThread();
    }


    public void myThread() {//创建子线程
        Thread myThread = new Thread(() -> {
            try {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("user_name", name1);
                values.put("user_code", code2);
                values.put("user_status", "正常");
                db.insert("users", null, values);
                values.clear();
                finish();
                Toast.makeText(this, "注册成功", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        myThread.start();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("name1", name1);
        outState.putString("code1", code1);
        outState.putString("code2", code2);
    }

    /**
     * 点击空白处
     * 输入框消失
     */
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {//获取当前获得焦点的View
            View view = getCurrentFocus();
            //调用方法判断是否需要隐藏键盘
            KeyBoardUtils.hideKeyboard(ev, view, this);
        }
        return super.dispatchTouchEvent(ev);
    }
}