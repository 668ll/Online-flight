package com.example.airplaindemo.ui.fragment;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.airplaindemo.MyDatabaseHelper;
import com.example.airplaindemo.R;
import com.example.airplaindemo.util.ToastDialogUtil;

import java.util.Objects;

/**
 * @author Run
 * @date 2023/3/14
 * @description 用户模式个人信息
 */
public class UserMineFragment extends Fragment {

    private TextView mTvStatus;
    private EditText mEtCode;
    private Button mBtUpdate;
    private String user_name, mStrUser, mStrCode, mStrStatus, mSqlUser, mSqlCode, mSqlStatus;
    private MyDatabaseHelper dbHelper;
    private SQLiteDatabase db;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_user_mine, container, false);
    }


    @SuppressLint("Range")
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        Bundle bundle = getArguments();
        assert bundle != null;
        user_name = (String) bundle.getString("mine_user");

        TextView mTvUser = getActivity().findViewById(R.id.tv_mine_user_done);
        mEtCode = getActivity().findViewById(R.id.et_mine_code);
        mTvStatus = getActivity().findViewById(R.id.tv_mine_status);
        mBtUpdate = getActivity().findViewById(R.id.bt_mine_update);

        dbHelper = new MyDatabaseHelper(getActivity(), "usersStore.db", null, 1);
        String selectQuery = "SELECT*FROM users where user_name like '%" + user_name + "%'";
        db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                mSqlUser = cursor.getString(cursor.getColumnIndex("user_name"));
                mSqlCode = cursor.getString(cursor.getColumnIndex("user_code"));
                mSqlStatus = cursor.getString(cursor.getColumnIndex("user_status"));
            } while (cursor.moveToNext());
        }
        cursor.close();
        if (user_name.equals(mSqlUser)) {
            mTvStatus.setText(mSqlStatus);
            mTvUser.setText(mSqlUser);
            mEtCode.setText(mSqlCode);
        } else {
            Log.i("UserMineFragment", "error");
        }

        mBtUpdate.setOnClickListener(v -> {
            mStrUser = mTvUser.getText().toString();
            mStrCode = mEtCode.getText().toString();
            mStrStatus = mTvStatus.getText().toString();
            if (mTvUser.length() == 0 || mEtCode.length() == 0) {
                ToastDialogUtil.showToast(getActivity(), "请输入新的用户名和密码");
            } else if (Objects.equals(mStrUser, user_name)) {
                ContentValues values = new ContentValues();
                values.put("user_name", mStrUser);
                values.put("user_code", mStrCode);
                db.update("users", values, "user_name=?", new String[]{user_name});
                new AlertDialog.Builder(getActivity()).setTitle("修改后需重新登录")
                        .setIcon(android.R.drawable.ic_dialog_info)
                        .setPositiveButton("确定修改", (dialog, which) -> {
                            android.os.Process.killProcess(android.os.Process.myPid());
                        })
                        .setNegativeButton("返回", (dialog, which) -> {
                        }).show();
            }

        });
    }
}
