package com.example.airplaindemo.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.airplaindemo.R;
import com.example.airplaindemo.list.PassengerData;

import java.util.List;

/**
 * 收货信息adapter
 */

public class PassengerAdapter extends BaseAdapter {

    private final List<PassengerData> mRecipientList;
    private final LayoutInflater inflater;

    public PassengerAdapter(List<PassengerData> mRecipientList, Context context) {
        this.mRecipientList = mRecipientList;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return mRecipientList == null ? 0 : mRecipientList.size();
    }

    @Override
    public Object getItem(int position) {
        return mRecipientList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressLint({"SetTextI18n", "MissingInflatedId", "LocalSuppress"})
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // 通过布局填充器将item_user布局文件转换为View对象

        View view = inflater.inflate(R.layout.item_passenger, null);
        PassengerData mPassengerData = (PassengerData) getItem(position);

        TextView tv_name = (TextView) view.findViewById(R.id.tv_passenger_name);
        TextView tv_tel = (TextView) view.findViewById(R.id.tv_passenger_tel);
        TextView tv_number = (TextView) view.findViewById(R.id.tv_passenger_number);

        tv_name.setText("姓名：" + mPassengerData.getName());
        tv_tel.setText("联系方式：" + mPassengerData.getTel());
        tv_number.setText("身份证号：" + mPassengerData.getNumber());

        // 返回填充好的View对象
        return view;
    }
}
