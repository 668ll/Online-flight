package com.example.airplaindemo.ui.activity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.airplaindemo.BaseActivity;
import com.example.airplaindemo.MyDatabaseHelper;
import com.example.airplaindemo.R;
import com.example.airplaindemo.ui.TimeDialog;
import com.example.airplaindemo.util.KeyBoardUtils;
import com.example.airplaindemo.util.ToastDialogUtil;

/**
 * @author Run
 * @date 2023/3/15
 * @description Admin mode flight edit
 */

public class FlightEditActivity extends BaseActivity implements View.OnClickListener {

    private String mStrStatus, mStrStatusName, id;
    private TextView mTvTitle, mTvStd, mTvEnd;
    private ImageView mIvBack;
    private EditText mEtNo, mEtFrom, mEtTo, mEtMoney, mEtNum;
    private String mStrNo, mStrStd, mStrEnd, mStrFrom, mStrTo, mStrMoney, mStrNum;
    private String mSqlId, mSqlNo, mSqlStd, mSqlEnd, mSqlFrom, mSqlTo, mSqlMoney, mSqlNum;
    private Button mBtSure;
    private MyDatabaseHelper dbHelper;
    private SQLiteDatabase db;
    private ContentValues values;
    private int amount;
    private RelativeLayout mNormal, mWait;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight_edit);
        dbHelper = new MyDatabaseHelper(this, "flightsStore.db", null, 1);
        dbHelper.getWritableDatabase();
        dbHelper.getReadableDatabase();

        mTvTitle = findViewById(R.id.tv_title);
        mIvBack = findViewById(R.id.iv_back);
        mEtNo = findViewById(R.id.et_edit_no);
        mTvStd = findViewById(R.id.tv_edit_std1);
        mTvEnd = findViewById(R.id.tv_edit_end1);
        mEtFrom = findViewById(R.id.et_edit_from);
        mEtTo = findViewById(R.id.et_edit_to);
        mEtMoney = findViewById(R.id.et_edit_money);
        mEtNum = findViewById(R.id.et_edit_num);

        mBtSure = findViewById(R.id.bt_edit_sure);
        mNormal = findViewById(R.id.rl_edit_flights);
        mWait = findViewById(R.id.rl_wait);

        mIvBack.setOnClickListener(this);
        mBtSure.setOnClickListener(this);
        mTvStd.setOnClickListener(this);
        mTvEnd.setOnClickListener(this);

        mNormal.setVisibility(View.VISIBLE);
        mWait.setVisibility(View.GONE);

        mStrStatus = getIntent().getStringExtra("flights_edit");
        id = getIntent().getStringExtra("flights_id");
        if (mStrStatus.equals("update")) {
            mStrStatusName = "Update";
            mEtNo.setFocusable(false);
            mEtNo.setFocusableInTouchMode(false);
            mEtNo.setEnabled(false);
            queryFlights();
        } else if (mStrStatus.equals("add")) {
            mStrStatusName = "Add";
        } else {
            Log.e("FlightEditActivity", "Title Error");
        }
        mBtSure.setText(mStrStatusName);
        mTvTitle.setText(mStrStatusName + " Flight");

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.iv_back) {
            finish();
        } else if (view.getId() == R.id.tv_edit_std1) {
            TimeDialog dialog = new TimeDialog(FlightEditActivity.this, 1);
            dialog.show();
        } else if (view.getId() == R.id.tv_edit_end1) {
            TimeDialog dialog = new TimeDialog(FlightEditActivity.this, 2);
            dialog.show();
        } else if (view.getId() == R.id.bt_edit_sure) {
            mWait.setVisibility(View.VISIBLE);
            mNormal.setVisibility(View.GONE);
            mStrNo = mEtNo.getText().toString();
            mStrStd = mTvStd.getText().toString();
            mStrEnd = mTvEnd.getText().toString();
            mStrFrom = mEtFrom.getText().toString();
            mStrTo = mEtTo.getText().toString();
            mStrMoney = mEtMoney.getText().toString();
            mStrNum = mEtNum.getText().toString();
            String[] std_list = mStrStd.split("[YearMonthDayHourMinute]+");
            String[] end_list = mStrEnd.split("[YearMonthDayHourMinute]+");
            int int_end = 0, int_std = 0;
            try {
                int_std = Integer.parseInt(std_list[0] + std_list[1] + std_list[2] + std_list[3] + std_list[4]);
                int_end = Integer.parseInt(end_list[0] + end_list[1] + end_list[2] + end_list[3] + end_list[4]);
            } catch (NumberFormatException e) {

            }

            if (mEtNo.length() == 0 || mStrStd.equals("Please select departure time") || mEtFrom.length() == 0 || mEtTo.length() == 0 || mStrEnd.equals("Please select landing time") || mEtMoney.length() == 0 || mEtNum.length() == 0) {
                ToastDialogUtil.showToast(this, mStrStatusName + " failed, please enter complete information");
                mWait.setVisibility(View.GONE);
                mNormal.setVisibility(View.VISIBLE);
            } else if (int_std > int_end) {
                ToastDialogUtil.showToast(this, "Please enter correct departure and landing times");
                mWait.setVisibility(View.GONE);
                mNormal.setVisibility(View.VISIBLE);
            } else {
                db = dbHelper.getWritableDatabase();
                values = new ContentValues();

                if (mStrStatus.equals("update")) {
                    // Update
                    values(mStrNo, mStrStd, mStrEnd, mStrFrom, mStrTo, mStrMoney, mStrNum);
                    Thread myThread = new Thread(() -> {
                        try {
                            db.update("flights", values, "id=?", new String[]{id});
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    });
                    myThread.start();
                    new Handler().postDelayed(() -> {
                        Toast.makeText(this, "Update Successful", Toast.LENGTH_SHORT).show();
                        finish();
                    }, 2500);
                } else if (mStrStatus.equals("add")) {
                    // Add
                    Cursor cursor = db.rawQuery("select * from flights", null);
                    amount = cursor.getCount();
                    if (amount == 0) {
                        Log.i("Add Data", "Flights table is empty");
                    }
                    values(mStrNo, mStrStd, mStrEnd, mStrFrom, mStrTo, mStrMoney, mStrNum);
                    Thread myThread = new Thread(() -> {
                        try {
                            db.insert("flights", null, values);
                            values.clear();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    });
                    myThread.start();
                    new Handler().postDelayed(() -> {
                        Log.i("flights", "Add Successful");
                        ToastDialogUtil.showToast(this, "Successfully added flight " + mStrNo);
                        finish();
                    }, 300);
                } else {
                    Log.e("FlightEditActivity", "bt_edit_sure Error");
                }
            }
        }
    }

    public void values(String no, String std, String end, String from, String to, String money, String num) {
        values.put("flights_no", no);
        values.put("flights_std", std);
        values.put("flights_end", end);
        values.put("flights_from", from);
        values.put("flights_to", to);
        values.put("flights_money", money);
        values.put("flights_num", num);
    }

    public void updateTextView(int type, String text) {
        if (type == 1) {
            mTvStd.setText(text);
        } else if (type == 2) {
            mTvEnd.setText(text);
        }
    }

    /**
     * Query flight database
     */
    @SuppressLint("Range")
    public void queryFlights() {
        String selectQuery = "SELECT*FROM flights where id like '%" + id + "%'";
        db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                mSqlId = cursor.getString(cursor.getColumnIndex("id"));
                mSqlNo = cursor.getString(cursor.getColumnIndex("flights_no"));
                mSqlStd = cursor.getString(cursor.getColumnIndex("flights_std"));
                mSqlEnd = cursor.getString(cursor.getColumnIndex("flights_end"));
                mSqlFrom = cursor.getString(cursor.getColumnIndex("flights_from"));
                mSqlTo = cursor.getString(cursor.getColumnIndex("flights_to"));
                mSqlMoney = cursor.getString(cursor.getColumnIndex("flights_money"));
                mSqlNum = cursor.getString(cursor.getColumnIndex("flights_num"));
            } while (cursor.moveToNext());
        }
        cursor.close();
        mEtNo.setText(mSqlNo);
        mTvStd.setText(mSqlStd);
        mTvEnd.setText(mSqlEnd);
        mEtFrom.setText(mSqlFrom);
        mEtTo.setText(mSqlTo);
        mEtMoney.setText(mSqlMoney);
        mEtNum.setText(mSqlNum);
    }
}
