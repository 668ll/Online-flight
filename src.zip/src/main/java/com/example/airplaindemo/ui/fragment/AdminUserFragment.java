package com.example.airplaindemo.ui.fragment;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.airplaindemo.MyDatabaseHelper;
import com.example.airplaindemo.R;
import com.example.airplaindemo.adapter.UserListAdapter;
import com.example.airplaindemo.list.UserData;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Run
 * @date 2023/3/14
 * @description 管理员模式用户信息
 */
public class AdminUserFragment extends Fragment {

    private MyDatabaseHelper dbHelper;
    private ListView mLvUser;
    private UserListAdapter adapter;
    private String user_name, user_code, user_status;
    private UserData mUserData;
    private SQLiteDatabase db;
    private List<UserData> mUserDataList;
    private ContentValues values;
    private RelativeLayout mRlEmpty;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_admin_user, container, false);
    }

    @SuppressLint("Range")
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mLvUser = (ListView) getActivity().findViewById(R.id.lv_ad_user_info);
        mRlEmpty = getActivity().findViewById(R.id.rl_user_empty);
        mUserData = new UserData();
        mUserDataList = new ArrayList<>();
        adapter = new UserListAdapter(mUserDataList, getActivity());

        dbHelper = new MyDatabaseHelper(getActivity(), "usersStore.db", null, 1);
        dbHelper.getWritableDatabase();

        find();

        mLvUser.setOnItemClickListener((adapterView, view, i, l) -> {
            mUserData = mUserDataList.get(i);
            String mStatus = mUserData.status;
            if (mStatus.equals("正常")) {
                AlertDialog dialog = new AlertDialog.Builder(getActivity())
                        .setMessage("确定要拉黑该用户吗？")
                        .setPositiveButton("确定", (dialogInterface, i1) -> {
                            if (!TextUtils.isEmpty(mUserData.name)) {
                                values = new ContentValues();
                                db = dbHelper.getWritableDatabase();
                                values.put("user_status", "黑名单");
                                db.update("users", values, "user_name=?", new String[]{mUserData.name});
                                find();
                                Toast.makeText(getActivity(), "拉黑" + mUserData.name + "成功", Toast.LENGTH_SHORT).show();
                            } else {
                                Log.e("AdminUserFragment", "删除用户失败");
                            }
                        })
                        .setNegativeButton("取消", null)
                        .create();
                dialog.show();
            } else if (mStatus.equals("黑名单")) {
                AlertDialog dialog = new AlertDialog.Builder(getActivity())
                        .setMessage("确定要取消拉黑该用户吗？")
                        .setPositiveButton("确定", (dialogInterface, i1) -> {
                            if (!TextUtils.isEmpty(mUserData.name)) {
                                values = new ContentValues();
                                db = dbHelper.getWritableDatabase();
                                values.put("user_status", "正常");
                                db.update("users", values, "user_name=?", new String[]{mUserData.name});
                                find();
                                Toast.makeText(getActivity(), "取消拉黑" + mUserData.name + "成功", Toast.LENGTH_SHORT).show();
                            } else {
                                Log.e("AdminUserFragment", "取消拉黑用户失败");
                            }
                        })
                        .setNegativeButton("取消", null)
                        .create();
                dialog.show();
            }
        });
        mLvUser.setOnItemLongClickListener((adapterView, view, i, l) -> {
            mUserData = mUserDataList.get(i);
            AlertDialog dialog = new AlertDialog.Builder(getActivity())
                    .setMessage("确定要删除该用户吗？")
                    .setPositiveButton("删除", (dialogInterface, i1) -> {
                        if (!TextUtils.isEmpty(mUserData.name)) {
                            db = dbHelper.getWritableDatabase();
                            db.delete("users", "user_name=?", new String[]{mUserData.name});
                            find();
                        } else {
                            Log.e("AdminUserFragment", mUserData.name + "已被删除");
                        }
                    })
                    .setNegativeButton("取消", null)
                    .create();
            dialog.show();
            return true;
        });

    }

    @SuppressLint("Range")
    public void find() {
        db = dbHelper.getReadableDatabase();
        Cursor c = db.query("users", null, null, null, null, null, null);
        mUserDataList.clear();
        adapter.notifyDataSetChanged();

        if (c.moveToFirst()) {
            do {
                user_name = c.getString(c.getColumnIndex("user_name"));
                user_code = c.getString(c.getColumnIndex("user_code"));
                user_status = c.getString(c.getColumnIndex("user_status"));

                UserData mUserData = new UserData();
                mUserData.name = user_name;
                mUserData.password = user_code;
                mUserData.status = user_status;
                mUserDataList.add(mUserData);
            } while (c.moveToNext());
        }
        try {
            c.close();
        } finally {
            c.close();
        }
        c.close();
        if (c.getCount() == 0) {
            mRlEmpty.setVisibility(View.VISIBLE);
            Log.i("AdminUserFragment", "c.getCount=0");
        } else {
            mRlEmpty.setVisibility(View.GONE);
            mLvUser.setAdapter(adapter);
        }
    }

}
