package com.example.airplaindemo.ui.activity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.example.airplaindemo.BaseActivity;
import com.example.airplaindemo.MyDatabaseHelper;
import com.example.airplaindemo.R;
import com.example.airplaindemo.util.ToastDialogUtil;

/**
 * @author Run
 * @date 2023/3/15
 * @description 用户模式购票页面
 */

public class BuyActivity extends BaseActivity {


    private MyDatabaseHelper dbHelper, flightHelper;
    private SQLiteDatabase database, flightDatabase;
    private ContentValues values, values1;
    private ImageView mIvBack;
    private String user_name, no, std, end, from, to, num, money, way;
    private String name, tel, number;
    private TextView mTvNo, mTvStd, mTvEnd, mTvFrom, mTvTo, mTvMoney, mTvNum;
    private TextView mTvName, mTvTel, mTvNumber;
    private Button mBtBuy, mBtPassenger;
    private RelativeLayout mRlInfo;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy);

        user_name = getIntent().getStringExtra("user_name");
        no = getIntent().getStringExtra("flights_no");
        std = getIntent().getStringExtra("flights_std");
        end = getIntent().getStringExtra("flights_end");
        from = getIntent().getStringExtra("flights_from");
        to = getIntent().getStringExtra("flights_to");
        money = getIntent().getStringExtra("flights_money");
        num = getIntent().getStringExtra("flights_num");

        mTvNo = findViewById(R.id.tv_info_no);
        mTvStd = findViewById(R.id.tv_info_std);
        mTvEnd = findViewById(R.id.tv_info_end);
        mTvFrom = findViewById(R.id.tv_info_from);
        mTvTo = findViewById(R.id.tv_info_to);
        mTvMoney = findViewById(R.id.tv_info_money);
        mTvNum = findViewById(R.id.tv_info_num);
        mTvNo.setText(no);
        mTvStd.setText(std);
        mTvEnd.setText(end);
        mTvFrom.setText(from);
        mTvTo.setText(to);
        mTvMoney.setText(money);
        mTvNum.setText(num);

        mTvName = findViewById(R.id.tv_title_traveller);
        mTvTel = findViewById(R.id.tv_title_tel);
        mTvNumber = findViewById(R.id.tv_title_number);

        mIvBack = findViewById(R.id.iv_back);
        mBtBuy = findViewById(R.id.bt_buy_sure);
        mBtPassenger = findViewById(R.id.bt_passenger);
        mRlInfo = findViewById(R.id.rl_order_info);
        RadioButton rb1 = (RadioButton) findViewById(R.id.rb_way1);
        RadioButton rb2 = (RadioButton) findViewById(R.id.rb_way2);
        RadioGroup rg1 = (RadioGroup) findViewById(R.id.rg_way);


        rg1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == rb1.getId()) {
                    way = "支付宝";
                } else if (checkedId == rb2.getId()) {
                    way = "微信";
                } else {
                    way = null;
                }
            }
        });

        mBtPassenger.setVisibility(View.VISIBLE);
        mRlInfo.setVisibility(View.INVISIBLE);
        dbHelper = new MyDatabaseHelper(this, "ordersStore.db", null, 1);
        flightHelper = new MyDatabaseHelper(this, "flightsStore.db", null, 1);

        mIvBack.setOnClickListener(v -> finish());
        mBtPassenger.setOnClickListener(v -> {
            Intent passengerIntent = new Intent(this, PassengerActivity.class);
            passengerIntent.putExtra("user_name", user_name);
            startActivityForResult(passengerIntent, 1002);
        });
        mBtBuy.setOnClickListener(v -> {
            if (name == null || tel == null || number == null||way==null) {
                ToastDialogUtil.showToast(this, "请输入乘客姓名和联系方式");
            } else {
                database = dbHelper.getWritableDatabase();
                flightDatabase = flightHelper.getWritableDatabase();
                values = new ContentValues();
                values1 = new ContentValues();
                values.put("order_user", user_name);
                values.put("order_way", way);
                values.put("order_money", money);
                values.put("passenger_name", name);
                values.put("passenger_tel", tel);
                values.put("passenger_num", number);
                values.put("flights_no", no);
                values.put("flights_std", std);
                database.insert("orders", null, values);
                values.clear();
                int num_int = Integer.parseInt(num) - 1;
                values1.put("flights_num", String.valueOf(num_int));
                flightDatabase.update("flights", values1, "flights_no=?", new String[]{no});
                finish();
                ToastDialogUtil.showToast(this, "购买成功");
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1002 && resultCode == RESULT_OK) {
            mBtPassenger.setVisibility(View.INVISIBLE);
            mRlInfo.setVisibility(View.VISIBLE);
            name = data.getStringExtra("passenger_name");
            tel = data.getStringExtra("passenger_tel");
            number = data.getStringExtra("passenger_num");
            mTvName.setText("乘机人姓名：" + name);
            mTvTel.setText("联系方式：" + tel);
            mTvNumber.setText("身份证号：" + number);
        }
    }
}